import pytest
from app.calculator import Calculator


class TestCalc:
    def setup_class(self):
        self.calc = Calculator

    def test_multiply_calculate_correctly(self):
        assert self.calc.multiply(self, 2, 2) == 4

#    def test_multiply_calculation_failed(self):
#        assert self.calc.multiply(self, 2, 2) == 5

    def test_division_calculate_correctly(self):
        assert self.calc.division(self, 8, 2) == 4

    def test_subtraction_calculate_correctly(self):
        assert self.calc.subtraction(self, 8, 4) == 4

    def test_adding_calculate_correctly(self):
        assert self.calc.adding(self, 6, 4) == 10

    def teardown_class (self):
        pass
